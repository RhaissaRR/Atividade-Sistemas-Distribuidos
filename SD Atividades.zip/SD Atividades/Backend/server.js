const express = require('express');
const cors = require('cors');

const app = express();

app.use(cors());
app.use(express.json());

app.get('/mensagem', (req, res) => {
  res.json({
    status: 'Servidor funcionando',
    mensagem: 'Comunicação Cliente-Servidor realizada com sucesso'
  });
});

app.listen(3000, () => {
  console.log('Servidor rodando na porta 3000');
});